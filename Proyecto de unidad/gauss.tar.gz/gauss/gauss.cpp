/***************************************************************************
 *   Copyright (C) 2008 by Nelson G. Lombardo                              *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/
/*
Este programa cacula basicamente un sistema de ecuaciones a travez del metodo
de Gauss-Jordan.
Esta orientado para el uso con el metodo de resolución de circuitos electricos 
de Kirchoff.
*/
#include <iostream>
#include <cstdlib>

using namespace std;

void gauss (double **matriz, int c, int i);
void put_zero(double **matriz, int c, int i);
void div_pivot(double **matriz, int c, int i);
void gauss_method(double **matriz, int i);
void show_i(double **matriz, int i);
void input(double **matriz, int i);

int main(int argc, char *argv[])
{
	int i, n, m, c;
	double **matriz, copy;
	cout << "Cantidad de incongnitas: "; cin >> i; cout << endl;
	matriz = new double*[i];
	for (n=0; n<i; n++)
		matriz[n] = new double[i+1];
	input(matriz, i);
	gauss_method(matriz, i);
	show_i(matriz, i);
	delete matriz;
	return EXIT_SUCCESS;
}

void gauss (double **matriz, int c, int i)
{
	int n, m;	
	for (n=0; n<i; n++)
	{
		for (m=0; m<(i+1); m++)
		{
			
			if ((n!=c)&&(m!=c))
			{
				matriz[n][m] = (matriz[n][m])-((matriz[n][c])*(matriz[c][m]));
			}
		}
		}
}

void put_zero(double **matriz, int c, int i)
{
	int n;
	for (n=0; n<i; n++)
	{
		if (n!=c) matriz[n][c] = 0;
	}
}

void div_pivot(double **matriz, int c, int i)
{
	double copy;
	int m;
	copy = matriz[c][c];
	for (m=0; m<(i+1); m++)
		matriz[c][m] = matriz[c][m]/copy;
}

void gauss_method(double **matriz, int i)
{
	int c;
	for (c=0; c<i; c++)
	{
		// Dividir por el pivote
		div_pivot(matriz, c, i);
		//Aplicamos las operaciones
		gauss(matriz, c, i);
		// Poner todos a cero menos el pivote
		put_zero(matriz, c, i);
	}
}

void show_i(double **matriz, int i)
{
	int n;	
	for (n=0; n<i; n++)
	{
		cout << "\tI" << n << " es " << matriz[n][i] << " Amp." << endl;
	}
}

void input(double **matriz, int i)
{
	int n, m;
	for (n=0; n<i; n++)
	{
		for (m=0; m<(i+1); m++)
		{
			cout << "Ingrese el dato [" << n << "][" << m << "]: ";
			cin >> matriz[n][m];
		}
	}
}
