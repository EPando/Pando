/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Classes;

/**
 *
 * @author Vazquez Aguilar
 */
public class preciosempleados {
    
}
